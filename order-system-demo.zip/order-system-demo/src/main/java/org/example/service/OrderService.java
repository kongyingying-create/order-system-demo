package org.example.service;

import org.example.common.Result;
import org.example.entity.OrderInfo;

public interface OrderService {
    Result<OrderInfo> createOrder(Long userId, Long productId);
}