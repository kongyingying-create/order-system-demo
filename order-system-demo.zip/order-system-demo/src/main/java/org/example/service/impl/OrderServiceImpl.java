package org.example.service.impl;

import org.example.common.Result;
import org.example.entity.OrderInfo;
import org.example.entity.Product;
import org.example.mapper.OrderInfoMapper;
import org.example.mapper.ProductMapper;
import org.example.service.OrderService;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

@Service
public class OrderServiceImpl implements OrderService {

    @Resource
    private ProductMapper productMapper;
    @Resource
    private OrderInfoMapper orderInfoMapper;
    @Resource
    private RedissonClient redissonClient;

    @Override
    @Transactional
    public Result<OrderInfo> createOrder(Long userId, Long productId) {
        RLock lock = redissonClient.getLock("lock:order:" + userId + ":" + productId);
        try {
            lock.lock(5, TimeUnit.SECONDS);

            Product product = productMapper.selectById(productId);
            if (product == null) return Result.fail("商品不存在");
            if (product.getStock() <= 0) return Result.fail("库存不足");

            int rows = productMapper.deductStock(productId);
            if (rows == 0) return Result.fail("库存扣减失败");

            OrderInfo order = new OrderInfo();
            order.setOrderNo(UUID.randomUUID().toString().replace("-", ""));
            order.setUserId(userId);
            order.setProductId(productId);
            order.setPrice(product.getPrice());
            order.setStatus(0);
            orderInfoMapper.insert(order);

            return Result.success(order);
        } finally {
            if (lock.isHeldByCurrentThread()) lock.unlock();
        }
    }
}