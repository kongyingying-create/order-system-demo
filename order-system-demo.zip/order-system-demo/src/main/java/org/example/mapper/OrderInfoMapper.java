package org.example.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.example.entity.OrderInfo;

public interface OrderInfoMapper extends BaseMapper<OrderInfo> {
}