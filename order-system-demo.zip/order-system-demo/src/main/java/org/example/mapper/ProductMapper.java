package org.example.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Update;
import org.example.entity.Product;

public interface ProductMapper extends BaseMapper<Product> {
    @Update("UPDATE product SET stock = stock - 1 WHERE id = #{id} AND stock > 0")
    int deductStock(Long id);
}