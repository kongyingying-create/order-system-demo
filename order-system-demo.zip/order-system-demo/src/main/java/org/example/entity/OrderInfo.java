package org.example.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@TableName("order_info")
public class OrderInfo {
    private Long id;
    private String orderNo;
    private Long userId;
    private Long productId;
    private BigDecimal price;
    private Integer status;
    private LocalDateTime createTime;
}